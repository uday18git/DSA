#!/bin/sh
# interpreter.sh
./4bechoall "$@"

